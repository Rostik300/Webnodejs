var width = window.innerWidth;
var height = window.innerHeight;

function loadImages( sources, callback ) {

    var images = {};
    var loadedImages = 0;
    var numImages = 0;

    for( var src in sources ) {

        numImages++;

    }

    for( var src in sources ) {

        images[ src ] = new Image();
        images[ src ].onload = function() {

            if( ++loadedImages >= numImages ) {

                callback( images );

            }

        };

        images[ src ].src = sources[ src ];

    }

}

function isNearOutline( car, outline ) {

    var a = car;
    var o = outline;
    var ax = a.getX();
    var ay = a.getY();

    if( ax > o.x - 20 && ax < o.x + 20 && ay > o.y - 20 && ay < o.y + 20 ) {

        return true;

    }

    else {

        return false;

    }

}

function drawBackground( background, dorogaImg, text ) {

    var context = background.getContext();

    let img = new Image();

    img.onload = function() {

      context.drawImage(this, 0, 0);
      context.setAttr( 'font', '20pt Calibri' );
      context.setAttr( 'textAlign', 'center' );
      context.setAttr( 'fillStyle', 'white' );
      context.fillText( text, background.getStage().getWidth() / 2, 40 );

    };

    img.src = 'img/doroga.jpg';
    //context.drawImage( dorogaImg, 0, 0 );

}

function initStage( images ) {

    var stage = new Konva.Stage({

        container: 'container',
        width: width,
        height: height

    });

    var background = new Konva.Layer();
    var carLayer = new Konva.Layer();
    var carShapes = [];
    var score = 0;

    var cars = {

        mercedes: {
            x: 3,
            y: 70
        },

        ferrari: {
            x: 400,
            y: 20
        },

        audi: {
            x: 750,
            y: 120
        },

        bwm: {
            x: 1110,
            y: 20
        }

    };

    var outlines = {

        mercedes_black: {
            x: 800,
            y: 350
        },

        ferrari_black: {
            x: 1100,
            y: 530
        },

        audi_black: {
            x: 420,
            y: 420
        },

        bwm_black: {
            x: 20,
            y: 390
        }

    };

    for( var key in cars ) {

      ( function() {

        var privKey = key;
        var anim = cars[ key ];
        var car = new Konva.Image({

        image: images[ key ],
        x: anim.x,
        y: anim.y,
        draggable: true

      });

      car.on( 'dragstart', function() {

        this.moveToTop();
        carLayer.draw();

      });

      car.on( 'dragend', function() {

        var outline = outlines[ privKey + '_black' ];

        if( !car.inRightPlace && isNearOutline( car, outline ) ) {

            car.position({

              x: outline.x,
              y: outline.y

            });

            carLayer.draw();
            car.inRightPlace = true;

            if( ++score >= 4 ) {

                var text = 'You win! Enjoy your booty!';
                drawBackground( background, images.dogora, text );

            }

            setTimeout( function() {

              car.draggable( false );

            }, 50 );

          }

      });

      car.on( 'mouseover', function() {

        car.image( images[ privKey + '_glow' ] );
        carLayer.draw();
        document.body.style.cursor = 'pointer';

      });

      car.on( 'mouseout', function() {

        car.image( images[ privKey ] );
        carLayer.draw();
        document.body.style.cursor = 'default';

      });

      car.on( 'dragmove', function() {

        document.body.style.cursor = 'pointer';

      });

      carLayer.add( car );
      carShapes.push( car );

    })();

  }

  for( var key in outlines ) {

    ( function() {

        var imageObj = images[ key ];
        var out = outlines[ key ];

        var outline = new Konva.Image({

            image: imageObj,
            x: out.x,
            y: out.y

        });

            carLayer.add( outline );

        })();

    }

    stage.add( background );
    stage.add( carLayer );

    drawBackground( background, images.doroga, 'Hello! Choosing a car on the road!' );
}

var sources = {

  doroga: 'img/doroga.jpg',
  mercedes: 'img/mercedes_1.png',
  mercedes_glow: 'img/mercedes_2.png',
  mercedes_black: 'img/mercedes_3.png',
  bwm: 'img/bwm_1.png',
  bwm_glow: 'img/bwm_2.png',
  bwm_black: 'img/bwm_3.png',
  audi: 'img/audi_1.png',
  audi_glow: 'img/audi_2.png',
  audi_black: 'img/audi_3.png',
  ferrari: 'img/ferrari_1.png',
  ferrari_glow: 'img/ferrari_2.png',
  ferrari_black: 'img/ferrari_3.png'

};

loadImages( sources, initStage );
