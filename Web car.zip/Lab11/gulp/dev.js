var gulp 		= require( 'gulp' ),
	  browserSync = require( 'browser-sync' ),
    concat 		= require( 'gulp-concat' ),
    uglify		= require( 'gulp-uglify' );

gulp.task( 'browser-sync', function() {

  browserSync({

    server: {

      baseDir: './src'

    }

  });

  notify: false

});

gulp.task( 'scripts', function() {

	return gulp.src([

		'./src/libs/konva/konva.min.js',
		'./src/libs/konva/konva.js'

	])

	.pipe( concat( 'libs.min.js' ) )
	.pipe( uglify() )
	.pipe( gulp.dest( './src/js' ) );


});

gulp.task( 'default', [ 'browser-sync', 'scripts' ], function() {

	gulp.watch( './src/*.html', browserSync.reload )

});
